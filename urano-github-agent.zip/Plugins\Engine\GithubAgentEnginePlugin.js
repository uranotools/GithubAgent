"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// Plugins/Engine/GithubAgentEnginePlugin.ts
var GithubAgentEnginePlugin_exports = {};
__export(GithubAgentEnginePlugin_exports, {
  GithubAgentEnginePlugin: () => GithubAgentEnginePlugin
});
module.exports = __toCommonJS(GithubAgentEnginePlugin_exports);
var import_EnginePluginBase = require("@core/EnginePluginBase");
var GithubAgentEnginePlugin = class extends import_EnginePluginBase.EnginePluginBase {
  async onSessionStart(ctx) {
    console.log(`[GithubAgentEnginePlugin] Session started: ${ctx.sessionId}`);
    const match = ctx.sessionId.match(/github:([^/]+)\/([^/]+)\/(pull|issue)\/(\d+)$/);
    if (match) {
      const [_, owner, repo, type, number] = match;
      ctx.addBadge({
        id: "github-repo",
        label: `\u{1F419} ${owner}/${repo}`,
        color: "info"
      });
      ctx.addBadge({
        id: "github-pr-issue",
        label: `${type === "pull" ? "PR" : "Issue"} #${number}`,
        color: "success"
      });
    }
  }
  async preMessageProcess(ctx, message) {
    const content = typeof message.content === "string" ? message.content : "";
    if (content.startsWith("/review-pr")) {
      const parts = content.split("\n")[0].split(" ");
      const diffUrl = parts[1];
      const title = parts.slice(2).join(" ");
      if (!diffUrl) {
        return {
          status: "intercepted",
          overrideResponse: "\u274C Error: No se proporcion\xF3 la URL de diff del Pull Request."
        };
      }
      ctx.addBadge({
        id: "review-progress",
        label: "\u{1F50D} Inicializando revisi\xF3n del PR...",
        color: "info"
      });
      try {
        const pat = ctx.getSecret("GITHUB_PAT");
        const headers = {
          "User-Agent": "Urano-Github-Agent"
        };
        if (pat) {
          headers["Authorization"] = `token ${pat}`;
        }
        const response = await fetch(diffUrl, { headers });
        if (!response.ok) {
          throw new Error(`No se pudo obtener el diff (${response.status}): ${await response.text()}`);
        }
        let diffText = await response.text();
        const MAX_DIFF_LENGTH = 3e4;
        if (diffText.length > MAX_DIFF_LENGTH) {
          diffText = diffText.substring(0, MAX_DIFF_LENGTH) + "\n\n... [DIFF TRUNCADO POR TAMA\xD1O] ...";
        }
        const result = await ctx.spawnSubSession({
          systemPrompt: "Eres un Arquitecto de Software y Revisor de C\xF3digo Senior de Urano AI. Analiza el diff de c\xF3digo proporcionado de forma rigurosa. Encuentra posibles bugs, fallos de seguridad (como inyecci\xF3n de SQL, claves expuestas), problemas de rendimiento (bucles ineficientes, memory leaks) y violaciones de dise\xF1o de software. Proporciona tus sugerencias de forma profesional, constructiva y estructurada con Markdown.",
          input: `Revisa este Pull Request titulado "${title}". Aqu\xED tienes el diff del c\xF3digo:

\`\`\`diff
${diffText}
\`\`\``,
          maxTokens: 4e3,
          timeout: 6e4,
          // 60s timeout limit
          priority: "high",
          silent: true,
          onProgress: (p) => {
            ctx.addBadge({
              id: "review-progress",
              label: `\u{1F50D} Revisando c\xF3digo... Paso: ${p.step} | Tokens: ${p.totalTokens}`,
              color: "info"
            });
          }
        });
        ctx.removeBadge("review-progress");
        if (result.status === "completed") {
          const report = `### \u{1F916} Urano AI Code Review

${result.summary}

*Revisado autom\xE1ticamente por el agente mediante Sandbox de Urano.*`;
          return {
            status: "intercepted",
            overrideResponse: report
          };
        } else if (result.status === "cancelled") {
          return {
            status: "intercepted",
            overrideResponse: "\u26A0\uFE0F La revisi\xF3n autom\xE1tica fue cancelada por tiempo de espera excedido (Timeout)."
          };
        } else {
          return {
            status: "intercepted",
            overrideResponse: "\u274C Error: El sandbox de revisi\xF3n fall\xF3."
          };
        }
      } catch (err) {
        ctx.removeBadge("review-progress");
        console.error("[GithubAgentEnginePlugin] Error reviewing PR:", err.message);
        return {
          status: "intercepted",
          overrideResponse: `\u274C Error al realizar la revisi\xF3n: ${err.message}`
        };
      }
    }
    return { status: "continue" };
  }
  async onSessionEnd(ctx) {
    ctx.removeBadge("github-repo");
    ctx.removeBadge("github-pr-issue");
    ctx.removeBadge("review-progress");
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  GithubAgentEnginePlugin
});
