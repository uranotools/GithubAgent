"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// config.ts
var config_exports = {};
__export(config_exports, {
  GithubAgentConfig: () => GithubAgentConfig,
  default: () => config_default
});
module.exports = __toCommonJS(config_exports);
var GithubAgentConfig = {
  name: "GithubAgent",
  description: "Revisor de c\xF3digo de GitHub e Issue Agent h\xEDbrido (Canal de Webhooks + Engine Plugin para revisiones de c\xF3digo en segundo plano).",
  icon: "GitPullRequest",
  category: "Productividad",
  inDesktop: true,
  inCloud: true,
  cloudOnly: false,
  // ──────────────────────────────────────────
  // CONFIGURACIÓN HÍBRIDA (Canal + Engine)
  // ──────────────────────────────────────────
  channelPlugin: true,
  enginePlugin: true,
  engineHooks: ["onSessionStart", "preMessageProcess"],
  settings: [
    {
      name: "GITHUB_PAT",
      title: "GitHub Personal Access Token (PAT)",
      type: "password",
      placeholder: "ghp_...",
      description: "Token de acceso de GitHub con permisos de escritura para publicar comentarios y reviews en repositorios.",
      required: true
    },
    {
      name: "GITHUB_WEBHOOK_SECRET",
      title: "GitHub Webhook Secret",
      type: "password",
      placeholder: "MiSecretoGithub",
      description: "Secreto de webhook para verificar las firmas HMAC SHA-256 de las peticiones entrantes de GitHub.",
      required: false
    },
    {
      name: "TARGET_AGENT",
      title: "ID del Agente Enrutador",
      type: "text",
      placeholder: "Ej: ceo o mi_agente_github",
      description: "ID del agente de Urano que procesar\xE1 e interactuar\xE1 con los mensajes y reviews de este canal de GitHub.",
      required: false
    }
  ],
  pluginSchemas: {}
};
var config_default = GithubAgentConfig;
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  GithubAgentConfig
});
