"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// Plugins/Channel/ChannelPlugin.ts
var ChannelPlugin_exports = {};
__export(ChannelPlugin_exports, {
  ChannelPlugin: () => ChannelPlugin
});
module.exports = __toCommonJS(ChannelPlugin_exports);
var crypto = __toESM(require("crypto"));
var ChannelPlugin = class {
  config;
  constructor(moduleConfig) {
    this.config = moduleConfig || {};
  }
  async executeAction(action, payload) {
    if (action === "validateWebhook") {
      const { req } = payload;
      const secret = this.config.GITHUB_WEBHOOK_SECRET;
      if (!secret) {
        return true;
      }
      const signature = req.headers["x-hub-signature-256"];
      if (!signature) {
        console.warn("[GithubAgent/Channel] Missing x-hub-signature-256 header");
        return false;
      }
      try {
        const hmac = crypto.createHmac("sha256", secret);
        const computed = "sha256=" + hmac.update(req.rawBody).digest("hex");
        return crypto.timingSafeEqual(
          Buffer.from(signature),
          Buffer.from(computed)
        );
      } catch (err) {
        console.error("[GithubAgent/Channel] Error validating signature:", err.message);
        return false;
      }
    }
    if (action === "parseWebhook") {
      const { req } = payload;
      const event = req.headers["x-github-event"] || "";
      const body = req.body || {};
      const sender = body.sender || {};
      if (sender.type === "Bot" || sender.login && (sender.login.includes("[bot]") || sender.login.toLowerCase().includes("urano"))) {
        return { from: "", text: "" };
      }
      const repo = body.repository || {};
      const repoFullName = repo.full_name;
      if (!repoFullName) {
        return { from: "", text: "" };
      }
      if (event === "pull_request") {
        const prAction = body.action;
        if (prAction === "opened" || prAction === "synchronize") {
          const pr = body.pull_request || {};
          const prNumber = body.number;
          const diffUrl = pr.diff_url;
          const title = pr.title || "PR";
          const prDescription = pr.body || "";
          const fromIdentifier = `github:${repoFullName}/pull/${prNumber}`;
          const text = `/review-pr ${diffUrl} ${title}

${prDescription}`;
          return {
            from: fromIdentifier,
            text
          };
        }
      }
      if (event === "issue_comment" || event === "pull_request_review_comment") {
        const commentAction = body.action;
        if (commentAction === "created") {
          const comment = body.comment || {};
          const commentText = comment.body || "";
          if (!commentText.trim()) {
            return { from: "", text: "" };
          }
          const issueNumber = (body.issue || body.pull_request || {}).number || body.number;
          if (!issueNumber) {
            return { from: "", text: "" };
          }
          const isPr = !!(body.issue?.pull_request || body.pull_request || event === "pull_request_review_comment");
          const type = isPr ? "pull" : "issue";
          const fromIdentifier = `github:${repoFullName}/${type}/${issueNumber}`;
          return {
            from: fromIdentifier,
            text: commentText
          };
        }
      }
      return { from: "", text: "" };
    }
    if (action === "sendReply") {
      const { to, text } = payload;
      const pat = this.config.GITHUB_PAT;
      if (!pat) {
        throw new Error("[GithubAgent/Channel] Cannot send reply: GITHUB_PAT is not configured in secrets.");
      }
      const match = to.match(/^github:([^/]+)\/([^/]+)\/(pull|issue)\/(\d+)$/);
      if (!match) {
        throw new Error(`[GithubAgent/Channel] Invalid recipient identifier: ${to}`);
      }
      const [_, owner, repo, type, numberStr] = match;
      const number = parseInt(numberStr, 10);
      const apiUrl = `https://api.github.com/repos/${owner}/${repo}/issues/${number}/comments`;
      const res = await fetch(apiUrl, {
        method: "POST",
        headers: {
          "Authorization": `token ${pat}`,
          "Accept": "application/vnd.github.v3+json",
          "User-Agent": "Urano-Github-Agent",
          "Content-Type": "application/json"
        },
        body: JSON.stringify({ body: text })
      });
      if (!res.ok) {
        const errText = await res.text();
        throw new Error(`[GithubAgent/Channel] GitHub API error (${res.status}): ${errText}`);
      }
      const data = await res.json();
      return { sid: String(data.id || Date.now()) };
    }
    if (action === "handleHandshake") {
      return null;
    }
    if (action === "getCustomTools") {
      return [];
    }
    throw new Error(`Action ${action} not implemented in ChannelPlugin`);
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  ChannelPlugin
});
